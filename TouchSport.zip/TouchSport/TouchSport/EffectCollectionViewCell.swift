//
//  EffectCollectionViewCell.swift
//  TouchSport
//
//  Created by Treinamento on 19/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class EffectCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var nomeCell: UILabel!
    
}
