//
//  SportsCollectionViewCell.swift
//  TouchSport
//
//  Created by Treinamento on 12/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class SportsCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var sportImage: UIImageView!
    @IBOutlet weak var nomeEsporte: UILabel!
    
    
}
