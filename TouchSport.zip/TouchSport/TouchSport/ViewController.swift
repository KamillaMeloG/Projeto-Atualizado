//
//  ViewController.swift
//  TouchSport
//
//  Created by Treinamento on 12/05/18.
//  Copyright © 2018 Treinamento. All rights reserved.
//

import UIKit

class Esportes{
    
    var nome : String
    var informacoes : String?
    var modalidades : [String]?
    var beneficios : [String]?
    var regras : [String]?
    var image: UIImage?
    
    init(nome: String, informacoes: String, modalidades: [String], beneficios: [String], regras: [String], imagem: UIImage){
        self.nome = nome
        self.informacoes = informacoes
        self.modalidades = modalidades
        self.beneficios = beneficios
        self.regras = regras
        self.image = imagem
    }
    
    init(nome: String) {
        self.nome = nome
    }
    
}

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIScrollViewDelegate {
   
    @IBOutlet weak var SportsCollection: UICollectionView!
    
    
    var arrayOfSports: [Esportes] = [
        Esportes.init(nome: "Futebol", informacoes: "Jogado entre dois times de 11 jogadores cada um e um árbitro que se ocupa da correta aplicação das normas. O objetivo do jogo é deslocar uma bola através do campo para colocá-la dentro da baliza adversária, ação que se denomina gol, A equipe que marca mais gols ao término da partida é a vencedora", modalidades: ["De salão , De areia"], beneficios: ["1 , 2"], regras: ["Regra 1", "Regra 2"], imagem: UIImage(named: "Futebol")!),
                                     Esportes.init(nome: "Teste2"),
                                     Esportes.init(nome: "Teste3"),
                                     Esportes.init(nome: "Teste4"),
                                     Esportes.init(nome: "Teste5"),
                                     Esportes.init(nome: "Teste6"),
                                     Esportes.init(nome: "TEste7"),
                                     Esportes.init(nome: "Teste8")]
   
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrayOfSports.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.SportsCollection.dequeueReusableCell(withReuseIdentifier: "Menu", for: indexPath) as! SportsCollectionViewCell
        
        cell.sportImage.image = self.arrayOfSports[indexPath.row].image
        cell.nomeEsporte.text = self.arrayOfSports[indexPath.row].nome
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "EsporteSegue", sender: self.arrayOfSports[indexPath.row])
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "EsporteSegue" {
            let content = sender as! Esportes
            print(content.nome)
            
            let vc = segue.destination as! InfoViewController
            
            vc.esporteSelecionado = content
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        SportsCollection.delegate = self
        SportsCollection.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

